from functions import analiz_et
analiz_et()
